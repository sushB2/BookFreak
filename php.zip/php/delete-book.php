<?php
session_start();

#if admin is logged in
if (isset($_SESSION['user_id']) &&
    isset($_SESSION['user_email'])) {


	#database connection file
	include "../db_conn.php";

	#check if book id set 
	if (isset($_GET['id'])) {

		#Get data from GET request and store it in var
		$id = $_GET['id'];


		#simple form validation
		if (empty($id)) {
			$em = "Error Occurred!";
			header("Location: ../admin.php?error=$em");
	  		exit;
		}else {

			#get the book from database
			$sql2 = "SELECT * FROM books WHERE id=?";
			$stmt2 = $conn->prepare($sql2);
			$stmt2->execute([$id]);
			$book = $stmt2->fetch();

			if ($stmt2->rowCount() > 0) {
				#delete the book from Database
				$sql = "DELETE FROM books WHERE id=?";
				$stmt = $conn->prepare($sql);
				$res = $stmt->execute([$id]);

				$sql3 = " ALTER TABLE books AUTO_INCREMENT = 1";
				$stmt3 = $conn->prepare($sql3);
				$res2 = $stmt3->execute([$id]);


				#if there is no error while deleting data
					if ($res2) {

						# delete the current book cover and the file
						$cover = $book['cover'];
						$file = $book['file'];
						$curr_co_pa = "../uploads/cover/$cover";
						$curr_fil_pa = "../uploads/file/$file";

						unlink($curr_co_pa);
						unlink($curr_fil_pa);


						#success message
						$sm = "Successfully removed!";
						header("Location: ../admin.php?success=$sm");
			  			exit;


					}else {
						#Error message
						$em = "Unknown error Occurred!";
						header("Location: ../admin.php?error=$em");
			  			exit;
					}

			}else {
				$em = "Error Occurred!";
				header("Location: ../admin.php?error=$em");
		  		exit;
			}

		}

	}else{
	  header("Location: ../admin.php");
	  exit;
	}


}else{
  header("Location: ../login.php");
  exit;
}