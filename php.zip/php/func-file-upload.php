<?php

#File upload helper function
function upload_file($files, $allowed_exs, $path){
	#get data store them in var

	$file_name = $files['name'];
	$tmp_name = $files['tmp_name'];
	$error = $files['error'];

	#if there is no error occured while uploading
	if ($error === 0) {
		
		#get file extension store it in var
		#The pathinfo() function returns information about a file path. Syntax. pathinfo(path, options). Parameter Values. Parameter, Description. path, Required.
		$file_ex = pathinfo($file_name, PATHINFO_EXTENSION);


		#conver the file extension info lower case and store it in var
		$file_ex_lc = strtolower($file_ex);

		#check if the file extension exist un $allowed_exs array

		if (in_array($file_ex_lc, $allowed_exs)) {

			#remaining the file with random strings
			#The uniqid() function generates a unique ID based on the microtime (the current time in microseconds). 

			$new_file_name = uniqid("",true).'.'.$file_ex_lc;

			#assiging upload path
			$file_upload_path = '../uploads/'.$path.'/'.$new_file_name;

			# moving uploaded file to root directory upload/$path folder

			move_uploaded_file($tmp_name, $file_upload_path);

			# creating success message associative with named keys status and data

			$sm['status'] = 'success';
			$sm['data'] = $new_file_name;

			#return sm array
			return $sm;
			
		}else {

			/** creating error message associative(help) array with named keys status and data
			**/

			$em['status'] = 'error';
			$em['data'] = "You can't upload files of type";

			#return em array
			return $em;

		}


	}else {

		/** creating error message associative(help) array with named keys status and data
		**/

		$em['status'] = 'error';
		$em['data'] = 'Error occurred while uploading!';

		#return em array
		return $em;


	}


}