<?php
session_start();

#if admin is logged in
if (isset($_SESSION['user_id']) &&
    isset($_SESSION['user_email'])) {


	#database connection file
	include "../db_conn.php";

	#check if author id set 
	if (isset($_GET['id'])) {

		#Get data from GET request and store it in var
		$id = $_GET['id'];


		#simple form validation
		if (empty($id)) {
			$em = "Error Occurred!";
			header("Location: ../admin.php?error=$em");
	  		exit;
		}else {

				#delete the author from Database
				$sql = "DELETE FROM author WHERE id=?";
				$stmt = $conn->prepare($sql);
				$res = $stmt->execute([$id]);

				#if there is no error while deleting data
					if ($res) {
						#success message
						$sm = "Successfully removed!";
						header("Location: ../admin.php?success=$sm");
			  			exit;

			}else {
				$em = "Error Occurred!";
				header("Location: ../admin.php?error=$em");
		  		exit;
			}

		}

	}else{
	  header("Location: ../admin.php");
	  exit;
	}


}else{
  header("Location: ../login.php");
  exit;
}