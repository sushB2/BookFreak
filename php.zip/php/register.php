<?php 

if(isset($_POST['fname']) && 
   isset($_POST['email']) && 
   isset($_POST['password'])){

    include "../db_conn.php";

    $fname = $_POST['fname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $data = "fname=".$fname."&email=".$email;
    
    if (empty($fname)) {
    	$em = "Full name is required";
    	header("Location: ../register.php?error=$em&$data");
	    exit;
    }else if(empty($email)){
    	$em = "Email is required";
    	header("Location: ../register.php?error=$em&$data");
	    exit;
    }else if(empty($password)){
    	$em = "Password is required";
    	header("Location: ../register.php?error=$em&$data");
	    exit;
    }else {

    	// hashing the password
    	$password = password_hash($password, PASSWORD_DEFAULT);

    	$sql = "INSERT INTO users(fname, email, password) 
    	        VALUES(?,?,?)";
    	$stmt = $conn->prepare($sql);
    	$stmt->execute([$fname, $email, $password]);

    	header("Location: ../register.php?success=Your account has been created successfully");
	    exit;
    }


}else {
	header("Location: ../register.php?error=error");
	exit;
}
