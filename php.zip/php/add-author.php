<?php
session_start();

#if admin is logged in
if (isset($_SESSION['user_id']) &&
    isset($_SESSION['user_email'])) {


	#database connection file
	include "../db_conn.php";

	#check if author name is submitted
	if (isset($_POST['author_name'])) {
		#Get data from POST request and store it in va
		$name = $_POST['author_name'];

		#simple form validation
		if (empty($name)) {
			$em = "The author name is required";
			header("Location: ../add-author.php?error=$em");
	  		exit;
		}else {

			#insert into Database
			$sql = "INSERT INTO author (name) VALUES (?)";
			$stmt = $conn->prepare($sql);
			$res = $stmt->execute([$name]);

			#if there is no error while inserting data
			if ($res) {
				#success message
				$sm = "Successfully created!";
				header("Location: ../add-author.php?success=$sm");
	  			exit;
			}else {
				#Error message
				$em = "Unknown error Occurred!";
				header("Location: ../add-author.php?error=$em");
	  			exit;
			}

		}

	}else{
	  header("Location: ../admin.php");
	  exit;
	}


}else{
  header("Location: ../login.php");
  exit;
}