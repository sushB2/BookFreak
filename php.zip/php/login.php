<?php 
session_start();

if(isset($_POST['email']) && 
   isset($_POST['password'])){

    include "../db_conn.php";

    $email = $_POST['email'];
    $password = $_POST['password'];

    $data = "email=".$email;
    
    if(empty($email)){
      $em = "email is required";
      header("Location: ../login.php?error=$em&$data");
      exit;
    }else if(empty($password)){
      $em = "Password is required";
      header("Location: ../login.php?error=$em&$data");
      exit;
    }else {

      $sql = "SELECT * FROM users 
              WHERE email=?";
      $stmt = $conn->prepare($sql);
      $stmt->execute([$email]);

      if($stmt->rowCount() == 1){

          $user = $stmt->fetch();

          $id =  $user['id'];
          $fname =  $user['fname'];
          $email =  $user['email'];
          $pass =  $user['password'];
          
          if($email === $email){
             if(password_verify($password, $pass)){
                 $_SESSION['id'] = $id;
                 $_SESSION['fname'] = $fname;
                 header("Location:../home.php");
                 exit;
             }else {
               $em = "Incorect User name or password";
               header("Location: ../login.php?error=$em&$data");
               exit;
            }

          }else {
            $em = "Incorect User name or password";
            header("Location: ../login.php?error=$em&$data");
            exit;
         }

      }else {
         $em = "Incorect User name or password";
         header("Location: ../login.php?error=$em&$data");
         exit;
      }
    }


}else {
  header("Location: ../login.php?error=error");
  exit;
}
