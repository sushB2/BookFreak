<?php
session_start();

if (isset($_POST['email']) && 
	isset($_POST['password'])) {

	#database connection
	include "../db_conn.php";

	#validation helper function
	include "func-validation.php";

	/** 
	get data fom POST request and store then in var 
	**/

	$email = $_POST['email'];
	$password = $_POST['password'];

	#simple form validation
	$text = "Email";
	$location = "../login.php";
	$ms = "error";
	is_empty($email, $text, $location, $ms, "");

	$text = "Password";
	$location = "../login.php";
	$ms = "error";
	is_empty($password, $text, $location, $ms, "");

	# $stmt " obviously (I think) stands for "statement". As a variable name it's arbitrary, you can name that variable anything you want. $stmt is just rather idiomatic. A prepared statement as such is a database feature.

	#search for email
	$sql = "SELECT * FROM admin
			WHERE email=?";
	$stmt = $conn->prepare($sql);
    $stmt->execute([$email]);
    
	#if email is exist
	if ($stmt->rowCount() === 1) {

		#The $mode parameter determines how the fetch() returns the next row. If a query doesn’t accept a parameter, you can fetch a row from the result set as follows: First, execute the query by calling the query() method of the PDO object. Then, fetch each row from the result set using the fetch() method and a while loop

		$user = $stmt->fetch();

		$user_id = $user['id'];
		$user_email = $user['email'];
		$user_password = $user['password'];

		if ($email === $user_email) {
			if (password_verify($password, $user_password)) {
				#Session variables hold information about one single user, and are available to all pages in one application.
				$_SESSION['user_id'] = $user_id;
    			$_SESSION['user_email'] = $user_email;
    			header("Location: ../admin.php");

			}else{
				# Error message
		    	$em = "Incorrect User name or password";
		    	header("Location: ../login.php?error=$em");	
			}
		}else{
			# Error message
	    	$em = "Incorrect User name or password";
	    	header("Location: ../login.php?error=$em");		
		}

	 }else{
    	# Error message
    	$em = "Incorrect User name or password";
    	header("Location: ../login.php?error=$em");
    }


}else{
	#redirect to "" ./login.php"
	header("Location:  ../login.php");
}